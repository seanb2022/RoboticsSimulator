var searchData=
[
  ['radarparams_1595',['RadarParams',['../classOnlineMapsGooglePlaces_1_1RadarParams.html',1,'OnlineMapsGooglePlaces']]],
  ['requestparams_1596',['RequestParams',['../classOnlineMapsGooglePlaces_1_1RequestParams.html',1,'OnlineMapsGooglePlaces.RequestParams'],['../classOnlineMapsGoogleGeocoding_1_1RequestParams.html',1,'OnlineMapsGoogleGeocoding.RequestParams']]],
  ['resource_1597',['Resource',['../classOnlineMapsBingMapsElevationResult_1_1Resource.html',1,'OnlineMapsBingMapsElevationResult']]],
  ['resourceset_1598',['ResourceSet',['../classOnlineMapsBingMapsElevationResult_1_1ResourceSet.html',1,'OnlineMapsBingMapsElevationResult']]],
  ['reversegeocodingparams_1599',['ReverseGeocodingParams',['../classOnlineMapsGoogleGeocoding_1_1ReverseGeocodingParams.html',1,'OnlineMapsGoogleGeocoding']]],
  ['roundtrip_1600',['RoundTrip',['../classOnlineMapsOpenRouteServiceDirections_1_1RoundTrip.html',1,'OnlineMapsOpenRouteServiceDirections']]],
  ['route_1601',['Route',['../classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html',1,'OnlineMapsOpenRouteServiceDirectionResult.Route'],['../classOnlineMapsGoogleDirectionsResult_1_1Route.html',1,'OnlineMapsGoogleDirectionsResult.Route'],['../classOnlineMapsGPXObject_1_1Route.html',1,'OnlineMapsGPXObject.Route']]]
];
