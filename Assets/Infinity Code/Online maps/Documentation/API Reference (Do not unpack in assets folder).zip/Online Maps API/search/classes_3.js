var searchData=
[
  ['data_1403',['Data',['../classOnlineMapsQQSearchResult_1_1Data.html',1,'OnlineMapsQQSearchResult']]],
  ['directionparams_1404',['DirectionParams',['../classOnlineMapsOpenRouteService_1_1DirectionParams.html',1,'OnlineMapsOpenRouteService']]]
];
