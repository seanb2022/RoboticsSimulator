var classOnlineMapsAMapSearchResult_1_1IndoorData =
[
    [ "cpid", "classOnlineMapsAMapSearchResult_1_1IndoorData.html#a7a91caaa4e4416a46773024ac5d210ce", null ],
    [ "floor", "classOnlineMapsAMapSearchResult_1_1IndoorData.html#a9eb5ca094631342d00819cb4311f2f88", null ],
    [ "truefloor", "classOnlineMapsAMapSearchResult_1_1IndoorData.html#a419719c83b7bd385eafdc38aa386d051", null ]
];