var classOnlineMapsBuffer =
[
    [ "StateProps", "structOnlineMapsBuffer_1_1StateProps.html", "structOnlineMapsBuffer_1_1StateProps" ],
    [ "OnlineMapsBuffer", "classOnlineMapsBuffer.html#a47ece14789d092935fc611c3a8019ba5", null ],
    [ "ApplyTile", "classOnlineMapsBuffer.html#a897762c99c67647711bbefa83fea5e33", null ],
    [ "Dispose", "classOnlineMapsBuffer.html#af34558244119e924c738e5712862ec1b", null ],
    [ "GenerateFrontBuffer", "classOnlineMapsBuffer.html#afbf0b808e2320effdf9f637201d10d98", null ],
    [ "GetCorners", "classOnlineMapsBuffer.html#a94d96e7d935d375499a3598132ccd02e", null ],
    [ "SetColorToBuffer", "classOnlineMapsBuffer.html#a842827c39bdd278709ad8eeca63f0827", null ],
    [ "UnloadOldTiles", "classOnlineMapsBuffer.html#a81e3777ac638397360f61b93bd4cf1f5", null ],
    [ "UnloadOldTypes", "classOnlineMapsBuffer.html#a3b9c6c1d7771f4147ed14e3bd2bee08a", null ],
    [ "allowUnloadTiles", "classOnlineMapsBuffer.html#acb9812b1a3615b422c6bdabcc895911a", null ],
    [ "bufferPosition", "classOnlineMapsBuffer.html#a5a72694c11a5a216514b060defddb415", null ],
    [ "frontBuffer", "classOnlineMapsBuffer.html#a44b76c5d5ba6be580968dd3eb42ac1eb", null ],
    [ "frontBufferPosition", "classOnlineMapsBuffer.html#a44cb57e4b059c122f4655491cb5badb3", null ],
    [ "height", "classOnlineMapsBuffer.html#a3999d869b6378128ca62b62ece400c48", null ],
    [ "lastState", "classOnlineMapsBuffer.html#aec54d42148fe8014d1585d9eb4318a04", null ],
    [ "map", "classOnlineMapsBuffer.html#a683f8674cb71a450d1c45ec5d101e9c8", null ],
    [ "needUnloadTiles", "classOnlineMapsBuffer.html#a70b7a5c53546cd96319a608e341ca079", null ],
    [ "renderState", "classOnlineMapsBuffer.html#a02cdf819cee28949eb62e3e13cf1c416", null ],
    [ "status", "classOnlineMapsBuffer.html#abe886eccb01c0ee0f19dc1cda655b80f", null ],
    [ "width", "classOnlineMapsBuffer.html#a4d3913eca93a89e515d7b64f83aefb1d", null ],
    [ "topLeftPosition", "classOnlineMapsBuffer.html#a88b619caff0f5f4c37d4a30a6816357c", null ]
];